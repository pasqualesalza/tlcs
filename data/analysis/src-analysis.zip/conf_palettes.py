import seaborn as sns



GREEN_COLOR_HEX = '#5fba7d'
RED_COLOR_HEX = '#d65f5f'

MAGNITUDE_PALETTE = {
    'negligible': 'none',
    'small': '#ffcc66',
    'medium': '#eb9663',
    'large': '#d65f5f',
}

IBM_PALETTE = ['#6929c4', '#1192e8', '#005d5d', '#9f1853', '#fa4d56', '#570408', '#198038', '#002d9c', '#ee538b', '#b28600', '#009d9a', '#012749', '#8a3800', '#a56eff']

SEABORN_DEFAULT_PALETTE = sns.color_palette().as_hex()

SEABORN_SET2_PALETTE = sns.color_palette('Set2').as_hex()

TYPES_PALETTE = {
    'random': '#b3b3b3',
    'lucene': '#fc8d62',
    'deepcs': '#66c2a5',
    'zeroshot': '#e5c494',
    'nopretrain': '#e78ac3',
    'finetuned': '#8da0cb',
    'combined': '#a6d854',
}

RQS_PALETTE = {
    'rq1': '#d62728',
    'rq2': '#2ca02c',
    'rq3': '#ff7f0e',
    'rq4': '#1f77b4',
    'rq5': '#e377c2',
}

TOPK_MODELS_PALETTE = sns.color_palette('Set2', 50).as_hex()

PLOT_SHAPES = [
    # Filled
    'o',  # circle
    '^',  # triangle up
    's',  # square
    'D',  # Diamond
    'v',  # triangle down
    '*',  # star
    'p',  # pentagon
    '8',  # octagon
    '<',  # triangle left
    'h',  # hexagon1
    '>',  # triangle right
    'H',  # hexagon1
    'd',  # thin diamond
    
    # Unfilled
    '+',  # plus
    'x',  # x
    '.',  # point
    '1',  # tri_down
    '2',  # tri_up
    '3',  # tri_left
    '4',  # tri_right
    ',',  # pixel
    '_',  # hline
    '|',  # vline
    1,    # tickleft
    2,    # tickright
    3,    # tickup
    4,    # tickdown
]
