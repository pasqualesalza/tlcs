def pivot_table_grouping(dataframe, index, columns, values, aggfunc, index_sort=None, columns_sort=None, values_sort=None):
    """
    Define a function to produce a pivot table that group by some values, and apply an aggregation function.
    """

    # Group into a pivot table.
    result_df = dataframe.pivot_table(index=index, columns=columns, values=values, aggfunc=aggfunc)

    # Sort the index.
    if index_sort:
        if len(index_sort) == 1:
            result_df = result_df.reindex(index_sort[0])
        elif len(index_sort) > 1:
            for i, sorting in enumerate(index_sort):
                result_df = result_df.reindex(sorting, level=i)

    # Sort the columns.
    if columns_sort:
        if len(columns_sort) == 1:
            result_df = result_df.reindex(columns_sort[0], axis=1)
        if len(columns_sort) > 1:
            for i, sorting in enumerate(columns_sort):
                result_df = result_df.reindex(sorting, level=i, axis=1)

    return result_df
