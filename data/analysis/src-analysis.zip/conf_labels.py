METRICS_LABELS = {
    'mrr': 'MRR',
    'top_1': 'Top 1',
    'top_3': 'Top 3',
    'top_5': 'Top 5',
    'top_10': 'Top 10',
    'aroma': 'Aroma',
}

TEST_VALUES_LABELS = {
    'js': 'JavaScript',
    'ja': 'Java',
    'py': 'Python',
    'tp': 'Top',
}

MAGNITUDE_LABELS = {
    'negligible': 'N',
    'small': 'S',
    'medium': 'M',
    'large': 'L',
}

RQS_LABELS = {
    'rq1': 'RQ1',
    'rq2': 'RQ2',
    'rq3': 'RQ3',
    'rq4': 'RQ4',
    'rq5': 'RQ5',
}

TYPES_LABELS = {
    'random': 'Random',
    'lucene': 'Lucene',
    'deepcs': 'DeepCS',
    'zeroshot': 'Zero-shot',
    'nopretrain': 'No pre-train',
    'finetuned': 'Fine-tuned',
    'combined': 'Combined',
}

SIZES_LABELS = {
    'full': 'Full',
    '1k': '1K',
}
